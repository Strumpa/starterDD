
% Increase counter:

if (exist('idx', 'var'));
  idx = idx + 1;
else;
  idx = 1;
end;

% Version, title and date:

VERSION                   (idx, [1: 14])  = 'Serpent 2.1.32' ;
COMPILE_DATE              (idx, [1: 20])  = 'May 22 2026 15:13:22' ;
DEBUG                     (idx, 1)        = 0 ;
TITLE                     (idx, [1: 72])  = 'GE-14 BWR fuel cell (GE14_DOM) - Serpent2 export from starterDD, void 0%' ;
CONFIDENTIAL_DATA         (idx, 1)        = 0 ;
INPUT_FILE_NAME           (idx, [1: 25])  = 'GE14_DOM_00_endfb8r1.serp' ;
WORKING_DIRECTORY         (idx, [1: 69])  = '/home/apollon/p117902/working_dir/Serpent2_para_bateman/Linux_aarch64' ;
HOSTNAME                  (idx, [1:  6])  = 'planck' ;
CPU_TYPE                  (idx, [1:  4])  = '0x41' ;
CPU_MHZ                   (idx, 1)        = 3.0 ;
START_DATE                (idx, [1: 24])  = 'Thu May 28 11:58:05 2026' ;
COMPLETE_DATE             (idx, [1: 24])  = 'Sat Jun  6 18:17:42 2026' ;

% Run parameters:

POP                       (idx, 1)        = 2000000 ;
CYCLES                    (idx, 1)        = 5000 ;
SKIP                      (idx, 1)        = 1000 ;
BATCH_INTERVAL            (idx, 1)        = 1 ;
SRC_NORM_MODE             (idx, 1)        = 2 ;
SEED                      (idx, 1)        = 1779983885043 ;
UFS_MODE                  (idx, 1)        = 0 ;
UFS_ORDER                 (idx, 1)        = 1.00000;
NEUTRON_TRANSPORT_MODE    (idx, 1)        = 1 ;
PHOTON_TRANSPORT_MODE     (idx, 1)        = 0 ;
GROUP_CONSTANT_GENERATION (idx, 1)        = 1 ;
B1_CALCULATION            (idx, [1:  3])  = [ 0 0 0 ];
B1_BURNUP_CORRECTION      (idx, 1)        = 0 ;

CRIT_SPEC_MODE            (idx, 1)        = 0 ;
IMPLICIT_REACTION_RATES   (idx, 1)        = 1 ;

% Optimization:

OPTIMIZATION_MODE         (idx, 1)        = 4 ;
RECONSTRUCT_MICROXS       (idx, 1)        = 1 ;
RECONSTRUCT_MACROXS       (idx, 1)        = 1 ;
DOUBLE_INDEXING           (idx, 1)        = 0 ;
MG_MAJORANT_MODE          (idx, 1)        = 0 ;

% Parallelization:

MPI_TASKS                 (idx, 1)        = 1 ;
OMP_THREADS               (idx, 1)        = 10 ;
MPI_REPRODUCIBILITY       (idx, 1)        = 0 ;
OMP_REPRODUCIBILITY       (idx, 1)        = 1 ;
OMP_HISTORY_PROFILE       (idx, [1:  10]) = [  1.00120E+00  1.00037E+00  1.00083E+00  1.00061E+00  9.98519E-01  9.99812E-01  9.99900E-01  1.00037E+00  9.99793E-01  9.98594E-01  ];
SHARE_BUF_ARRAY           (idx, 1)        = 0 ;
SHARE_RES2_ARRAY          (idx, 1)        = 1 ;
OMP_SHARED_QUEUE_LIM      (idx, 1)        = 0 ;

% File paths:

XS_DATA_FILE_PATH         (idx, [1: 75])  = '/home/apollon/p117902/Serpent2/xs/endfb8r1/endfb8r1_pynjoy2012_KERMA.xsdata' ;
DECAY_DATA_FILE_PATH      (idx, [1: 55])  = '/home/apollon/p117902/Serpent2/xs/endfb8r1/endfb8r1.dec' ;
SFY_DATA_FILE_PATH        (idx, [1: 55])  = '/home/apollon/p117902/Serpent2/xs/endfb8r1/endfb8r1.nfy' ;
NFY_DATA_FILE_PATH        (idx, [1: 55])  = '/home/apollon/p117902/Serpent2/xs/endfb8r1/endfb8r1.nfy' ;
BRA_DATA_FILE_PATH        (idx, [1:  3])  = 'N/A' ;

% Collision and reaction sampling (neutrons/photons):

MIN_MACROXS               (idx, [1:   4]) = [  5.00000E-02 0.0E+00  0.00000E+00 0.0E+00 ];
DT_THRESH                 (idx, [1:  2])  = [  9.00000E-01  9.00000E-01 ];
ST_FRAC                   (idx, [1:   4]) = [  3.65938E-01 7.0E-06  0.00000E+00 0.0E+00 ];
DT_FRAC                   (idx, [1:   4]) = [  6.34062E-01 4.0E-06  0.00000E+00 0.0E+00 ];
DT_EFF                    (idx, [1:   4]) = [  5.50698E-01 4.5E-06  0.00000E+00 0.0E+00 ];
REA_SAMPLING_EFF          (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
REA_SAMPLING_FAIL         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_COL_EFF               (idx, [1:   4]) = [  6.17990E-01 3.1E-06  0.00000E+00 0.0E+00 ];
AVG_TRACKING_LOOPS        (idx, [1:   8]) = [  6.16591E+00 9.1E-06  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_TRACKS                (idx, [1:   4]) = [  3.16106E+01 6.3E-06  0.00000E+00 0.0E+00 ];
AVG_REAL_COL              (idx, [1:   4]) = [  3.16106E+01 6.3E-06  0.00000E+00 0.0E+00 ];
AVG_VIRT_COL              (idx, [1:   4]) = [  1.95401E+01 1.2E-05  0.00000E+00 0.0E+00 ];
AVG_SURF_CROSS            (idx, [1:   4]) = [  1.74306E+01 1.5E-05  0.00000E+00 0.0E+00 ];
LOST_PARTICLES            (idx, 1)        = 0 ;

% Run statistics:

CYCLE_IDX                 (idx, 1)        = 5000 ;
SIMULATED_HISTORIES       (idx, 1)        = 10000008183 ;
MEAN_POP_SIZE             (idx, [1:  2])  = [  2.00000E+06 0.00002 ];
MEAN_POP_WGT              (idx, [1:  2])  = [  2.00000E+06 0.00002 ];
SIMULATION_COMPLETED      (idx, 1)        = 1 ;

% Running times:

TOT_CPU_TIME              (idx, 1)        =  1.26900E+05 ;
RUNNING_TIME              (idx, 1)        =  1.33396E+04 ;
INIT_TIME                 (idx, [1:  2])  = [  7.55967E-01  7.55967E-01 ];
PROCESS_TIME              (idx, [1:  2])  = [  4.50000E-02  4.50000E-02 ];
TRANSPORT_CYCLE_TIME      (idx, [1:  3])  = [  1.33388E+04  1.33388E+04  0.00000E+00 ];
MPI_OVERHEAD_TIME         (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
ESTIMATED_RUNNING_TIME    (idx, [1:  2])  = [  1.33396E+04  0.00000E+00 ];
CPU_USAGE                 (idx, 1)        = 9.51302 ;
TRANSPORT_CPU_USAGE       (idx, [1:   2]) = [  9.54541E+00 0.00031 ];
OMP_PARALLEL_FRAC         (idx, 1)        =  9.54403E-01 ;

% Memory usage:

AVAIL_MEM                 (idx, 1)        = 2058640.97 ;
ALLOC_MEMSIZE             (idx, 1)        = 28045.70;
MEMSIZE                   (idx, 1)        = 27910.47;
XS_MEMSIZE                (idx, 1)        = 3424.13;
MAT_MEMSIZE               (idx, 1)        = 11060.75;
RES_MEMSIZE               (idx, 1)        = 72.92;
IFC_MEMSIZE               (idx, 1)        = 0.00;
MISC_MEMSIZE              (idx, 1)        = 13352.68;
UNKNOWN_MEMSIZE           (idx, 1)        = 0.00;
UNUSED_MEMSIZE            (idx, 1)        = 135.22;

% Geometry parameters:

TOT_CELLS                 (idx, 1)        = 8 ;
UNION_CELLS               (idx, 1)        = 0 ;

% Neutron energy grid:

NEUTRON_ERG_TOL           (idx, 1)        =  0.00000E+00 ;
NEUTRON_ERG_NE            (idx, 1)        = 901016 ;
NEUTRON_EMIN              (idx, 1)        =  1.00000E-11 ;
NEUTRON_EMAX              (idx, 1)        =  2.00000E+01 ;

% Unresolved resonance probability table sampling:

URES_DILU_CUT             (idx, 1)        =  1.00000E-09 ;
URES_EMIN                 (idx, 1)        =  1.00000E+37 ;
URES_EMAX                 (idx, 1)        = -1.00000E+37 ;
URES_AVAIL                (idx, 1)        = 0 ;
URES_USED                 (idx, 1)        = 0 ;

% Nuclides and reaction channels:

TOT_NUCLIDES              (idx, 1)        = 51 ;
TOT_TRANSPORT_NUCLIDES    (idx, 1)        = 51 ;
TOT_DOSIMETRY_NUCLIDES    (idx, 1)        = 0 ;
TOT_DECAY_NUCLIDES        (idx, 1)        = 0 ;
TOT_PHOTON_NUCLIDES       (idx, 1)        = 0 ;
TOT_REA_CHANNELS          (idx, 1)        = 1746 ;
TOT_TRANSMU_REA           (idx, 1)        = 0 ;

% Neutron physics options:

USE_DELNU                 (idx, 1)        = 1 ;
USE_URES                  (idx, 1)        = 1 ;
USE_DBRC                  (idx, 1)        = 0 ;
IMPL_CAPT                 (idx, 1)        = 0 ;
IMPL_NXN                  (idx, 1)        = 1 ;
IMPL_FISS                 (idx, 1)        = 0 ;
DOPPLER_PREPROCESSOR      (idx, 1)        = 1 ;
TMS_MODE                  (idx, 1)        = 0 ;
SAMPLE_FISS               (idx, 1)        = 1 ;
SAMPLE_CAPT               (idx, 1)        = 1 ;
SAMPLE_SCATT              (idx, 1)        = 1 ;

% Energy deposition:

EDEP_MODE                 (idx, 1)        = 0 ;
EDEP_DELAYED              (idx, 1)        = 1 ;
EDEP_KEFF_CORR            (idx, 1)        = 1 ;
EDEP_LOCAL_EGD            (idx, 1)        = 0 ;
EDEP_COMP                 (idx, [1:  9])  = [ 0 0 0 0 0 0 0 0 0 ];
EDEP_CAPT_E               (idx, 1)        =  0.00000E+00 ;

% Radioactivity data:

TOT_ACTIVITY              (idx, 1)        =  5.19760E+07 ;
TOT_DECAY_HEAT            (idx, 1)        =  3.97955E-05 ;
TOT_SF_RATE               (idx, 1)        =  3.24568E+00 ;
ACTINIDE_ACTIVITY         (idx, 1)        =  5.19760E+07 ;
ACTINIDE_DECAY_HEAT       (idx, 1)        =  3.97955E-05 ;
FISSION_PRODUCT_ACTIVITY  (idx, 1)        =  0.00000E+00 ;
FISSION_PRODUCT_DECAY_HEAT(idx, 1)        =  0.00000E+00 ;
INHALATION_TOXICITY       (idx, 1)        =  4.78541E+02 ;
INGESTION_TOXICITY        (idx, 1)        =  2.51914E+00 ;
ACTINIDE_INH_TOX          (idx, 1)        =  4.78541E+02 ;
ACTINIDE_ING_TOX          (idx, 1)        =  2.51914E+00 ;
FISSION_PRODUCT_INH_TOX   (idx, 1)        =  0.00000E+00 ;
FISSION_PRODUCT_ING_TOX   (idx, 1)        =  0.00000E+00 ;
SR90_ACTIVITY             (idx, 1)        =  0.00000E+00 ;
TE132_ACTIVITY            (idx, 1)        =  0.00000E+00 ;
I131_ACTIVITY             (idx, 1)        =  0.00000E+00 ;
I132_ACTIVITY             (idx, 1)        =  0.00000E+00 ;
CS134_ACTIVITY            (idx, 1)        =  0.00000E+00 ;
CS137_ACTIVITY            (idx, 1)        =  0.00000E+00 ;
PHOTON_DECAY_SOURCE       (idx, 1)        =  8.36938E+06 ;
NEUTRON_DECAY_SOURCE      (idx, 1)        =  0.00000E+00 ;
ALPHA_DECAY_SOURCE        (idx, 1)        =  5.19535E+07 ;
ELECTRON_DECAY_SOURCE     (idx, 1)        =  4.19350E+07 ;

% Normalization coefficient:

NORM_COEF                 (idx, [1:   4]) = [  4.99373E-07 7.0E-06  0.00000E+00 0.0E+00 ];

% Analog reaction rate estimators:

CONVERSION_RATIO          (idx, [1:   2]) = [  3.97140E-01 2.7E-05 ];
U235_FISS                 (idx, [1:   4]) = [  3.79818E-01 1.5E-05  9.41831E-01 3.9E-06 ];
U238_FISS                 (idx, [1:   4]) = [  2.33987E-02 6.7E-05  5.80215E-02 6.4E-05 ];
U235_CAPT                 (idx, [1:   4]) = [  8.75542E-02 3.4E-05  1.46722E-01 3.2E-05 ];
U238_CAPT                 (idx, [1:   4]) = [  1.83847E-01 2.3E-05  3.08087E-01 1.9E-05 ];

% Neutron balance (particles/weight):

BALA_SRC_NEUTRON_SRC     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_FISS    (idx, [1:  2])  = [ 10000008183 1.00000E+10 ];
BALA_SRC_NEUTRON_NXN     (idx, [1:  2])  = [ 0 1.26732E+07 ];
BALA_SRC_NEUTRON_VR      (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_TOT     (idx, [1:  2])  = [ 10000008183 1.00127E+10 ];

BALA_LOSS_NEUTRON_CAPT    (idx, [1:  2])  = [ 5967134741 5.97484E+09 ];
BALA_LOSS_NEUTRON_FISS    (idx, [1:  2])  = [ 4032873442 4.03783E+09 ];
BALA_LOSS_NEUTRON_LEAK    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_CUT     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_ERR     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_TOT     (idx, [1:  2])  = [ 10000008183 1.00127E+10 ];

BALA_NEUTRON_DIFF         (idx, [1:  2])  = [ 0 1.72234E-03 ];

% Normalized total reaction rates (neutrons):

TOT_POWER                 (idx, [1:   2]) = [  1.30833E-11 7.2E-06 ];
TOT_POWDENS               (idx, [1:   2]) = [  2.61852E-17 7.2E-06 ];
TOT_GENRATE               (idx, [1:   2]) = [  9.89008E-01 7.2E-06 ];
TOT_FISSRATE              (idx, [1:   2]) = [  4.03269E-01 7.2E-06 ];
TOT_CAPTRATE              (idx, [1:   2]) = [  5.96731E-01 4.9E-06 ];
TOT_ABSRATE               (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
TOT_SRCRATE               (idx, [1:   2]) = [  9.98746E-01 7.0E-06 ];
TOT_FLUX                  (idx, [1:   2]) = [  4.35821E+01 6.3E-06 ];
TOT_PHOTON_PRODRATE       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_LEAKRATE              (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ALBEDO_LEAKRATE           (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_LOSSRATE              (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
TOT_CUTRATE               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_RR                    (idx, [1:   2]) = [  3.16099E+01 6.2E-06 ];
INI_FMASS                 (idx, 1)        =  4.99645E-01 ;
TOT_FMASS                 (idx, 1)        =  4.99645E-01 ;

% Six-factor formula:

SIX_FF_ETA                (idx, [1:   2]) = [  1.20859E+00 1.3E-05 ];
SIX_FF_F                  (idx, [1:   2]) = [  9.17392E-01 3.7E-06 ];
SIX_FF_P                  (idx, [1:   2]) = [  6.78794E-01 6.9E-06 ];
SIX_FF_EPSILON            (idx, [1:   2]) = [  1.31577E+00 8.9E-06 ];
SIX_FF_LF                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_LT                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_KINF               (idx, [1:   2]) = [  9.90267E-01 1.2E-05 ];
SIX_FF_KEFF               (idx, [1:   2]) = [  9.90267E-01 1.2E-05 ];

% Fission neutron and energy production:

NUBAR                     (idx, [1:   2]) = [  2.45248E+00 2.8E-07 ];
FISSE                     (idx, [1:   2]) = [  2.02494E+02 2.3E-08 ];

% Criticality eigenvalues:

ANA_KEFF                  (idx, [1:   6]) = [  9.90269E-01 1.3E-05  9.83534E-01 1.2E-05  6.73344E-03 0.00019 ];
IMP_KEFF                  (idx, [1:   2]) = [  9.90261E-01 7.2E-06 ];
COL_KEFF                  (idx, [1:   2]) = [  9.90250E-01 1.0E-05 ];
ABS_KEFF                  (idx, [1:   2]) = [  9.90261E-01 7.2E-06 ];
ABS_KINF                  (idx, [1:   2]) = [  9.90261E-01 7.2E-06 ];
GEOM_ALBEDO               (idx, [1:   6]) = [  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00 ];

% ALF (Average lethargy of neutrons causing fission):
% Based on E0 = 2.000000E+01 MeV

ANA_ALF                   (idx, [1:   2]) = [  1.71683E+01 4.5E-06 ];
IMP_ALF                   (idx, [1:   2]) = [  1.71683E+01 2.0E-06 ];

% EALF (Energy corresponding to average lethargy of neutrons causing fission):

ANA_EALF                  (idx, [1:   2]) = [  6.99709E-07 7.7E-05 ];
IMP_EALF                  (idx, [1:   2]) = [  6.99715E-07 3.4E-05 ];

% AFGE (Average energy of neutrons causing fission):

ANA_AFGE                  (idx, [1:   2]) = [  2.03999E-01 6.7E-05 ];
IMP_AFGE                  (idx, [1:   2]) = [  2.04017E-01 2.6E-05 ];

% Forward-weighted delayed neutron parameters:

PRECURSOR_GROUPS          (idx, 1)        = 6 ;
FWD_ANA_BETA_ZERO         (idx, [1:  14]) = [  7.18896E-03 0.00012  2.30686E-04 0.00066  1.22946E-03 0.00029  1.19796E-03 0.00029  2.77865E-03 0.00019  1.23744E-03 0.00028  5.14758E-04 0.00045 ];
FWD_ANA_LAMBDA            (idx, [1:  14]) = [  4.99762E-01 0.00017  1.33541E-02 3.5E-06  3.26075E-02 3.5E-06  1.21066E-01 1.9E-06  3.05742E-01 4.6E-06  8.61310E-01 7.7E-06  2.89301E+00 1.2E-05 ];

% Beta-eff using Meulekamp's method:

ADJ_MEULEKAMP_BETA_EFF    (idx, [1:  14]) = [  6.86291E-03 0.00018  2.19954E-04 0.00099  1.17207E-03 0.00043  1.14197E-03 0.00043  2.65390E-03 0.00028  1.18235E-03 0.00041  4.92670E-04 0.00066 ];
ADJ_MEULEKAMP_LAMBDA      (idx, [1:  14]) = [  5.00442E-01 0.00026  1.33540E-02 5.2E-06  3.26074E-02 5.3E-06  1.21066E-01 2.9E-06  3.05743E-01 6.8E-06  8.61309E-01 1.1E-05  2.89303E+00 1.8E-05 ];

% Adjoint weighted time constants using Nauchi's method:

IFP_CHAIN_LENGTH          (idx, 1)        = 15 ;
ADJ_NAUCHI_GEN_TIME       (idx, [1:   6]) = [  2.57036E-05 2.8E-05  2.56906E-05 2.8E-05  2.76101E-05 0.00028 ];
ADJ_NAUCHI_LIFETIME       (idx, [1:   6]) = [  2.54535E-05 2.5E-05  2.54406E-05 2.5E-05  2.73414E-05 0.00028 ];
ADJ_NAUCHI_BETA_EFF       (idx, [1:  14]) = [  6.79957E-03 0.00019  2.17655E-04 0.00109  1.16131E-03 0.00047  1.13145E-03 0.00048  2.63046E-03 0.00031  1.17084E-03 0.00047  4.87853E-04 0.00073 ];
ADJ_NAUCHI_LAMBDA         (idx, [1:  14]) = [  5.00295E-01 0.00028  1.33541E-02 5.8E-06  3.26074E-02 5.9E-06  1.21066E-01 3.2E-06  3.05743E-01 7.5E-06  8.61315E-01 1.2E-05  2.89295E+00 2.0E-05 ];

% Adjoint weighted time constants using IFP:

ADJ_IFP_GEN_TIME          (idx, [1:   6]) = [  2.57015E-05 6.5E-05  2.56884E-05 6.6E-05  2.76132E-05 0.00072 ];
ADJ_IFP_LIFETIME          (idx, [1:   6]) = [  2.54513E-05 6.4E-05  2.54384E-05 6.4E-05  2.73445E-05 0.00072 ];
ADJ_IFP_IMP_BETA_EFF      (idx, [1:  14]) = [  6.79931E-03 0.00062  2.16734E-04 0.00353  1.16341E-03 0.00149  1.13189E-03 0.00150  2.62892E-03 0.00100  1.16975E-03 0.00147  4.88617E-04 0.00233 ];
ADJ_IFP_IMP_LAMBDA        (idx, [1:  14]) = [  5.00440E-01 0.00091  1.33544E-02 1.9E-05  3.26063E-02 1.9E-05  1.21067E-01 9.9E-06  3.05741E-01 2.4E-05  8.61307E-01 4.0E-05  2.89274E+00 6.4E-05 ];
ADJ_IFP_ANA_BETA_EFF      (idx, [1:  14]) = [  6.79965E-03 0.00061  2.16694E-04 0.00345  1.16298E-03 0.00145  1.13201E-03 0.00147  2.62917E-03 0.00097  1.16983E-03 0.00144  4.88968E-04 0.00227 ];
ADJ_IFP_ANA_LAMBDA        (idx, [1:  14]) = [  5.00590E-01 0.00089  1.33543E-02 1.8E-05  3.26065E-02 1.8E-05  1.21067E-01 9.7E-06  3.05742E-01 2.3E-05  8.61306E-01 3.8E-05  2.89271E+00 6.2E-05 ];
ADJ_IFP_ROSSI_ALPHA       (idx, [1:   2]) = [ -2.64691E+02 0.00063 ];

% Adjoint weighted time constants using perturbation technique:

ADJ_PERT_GEN_TIME         (idx, [1:   2]) = [  2.57239E-05 1.8E-05 ];
ADJ_PERT_LIFETIME         (idx, [1:   2]) = [  2.54735E-05 1.2E-05 ];
ADJ_PERT_BETA_EFF         (idx, [1:   2]) = [  6.80683E-03 0.00012 ];
ADJ_PERT_ROSSI_ALPHA      (idx, [1:   2]) = [ -2.64612E+02 0.00012 ];

% Inverse neutron speed :

ANA_INV_SPD               (idx, [1:   2]) = [  4.94620E-07 1.2E-05 ];

% Analog slowing-down and thermal neutron lifetime (total/prompt/delayed):

ANA_SLOW_TIME             (idx, [1:   6]) = [  2.65287E-06 9.4E-06  2.65289E-06 9.4E-06  2.64916E-06 0.00011 ];
ANA_THERM_TIME            (idx, [1:   6]) = [  2.87179E-05 1.3E-05  2.87182E-05 1.4E-05  2.86666E-05 0.00016 ];
ANA_THERM_FRAC            (idx, [1:   6]) = [  6.79378E-01 6.9E-06  6.79292E-01 7.0E-06  6.91377E-01 0.00019 ];
ANA_DELAYED_EMTIME        (idx, [1:   2]) = [  1.05162E+01 0.00028 ];
ANA_MEAN_NCOL             (idx, [1:   4]) = [  3.16106E+01 6.3E-06  3.37750E+01 1.0E-05 ];

% Group constant generation:

GC_UNIVERSE_NAME          (idx, [1:  1])  = '0' ;

% Micro- and macro-group structures:

MICRO_NG                  (idx, 1)        = 70 ;
MICRO_E                   (idx, [1:  71]) = [  2.00000E+01  6.06550E+00  3.67900E+00  2.23100E+00  1.35300E+00  8.21000E-01  5.00000E-01  3.02500E-01  1.83000E-01  1.11000E-01  6.74300E-02  4.08500E-02  2.47800E-02  1.50300E-02  9.11800E-03  5.50000E-03  3.51910E-03  2.23945E-03  1.42510E-03  9.06898E-04  3.67262E-04  1.48728E-04  7.55014E-05  4.80520E-05  2.77000E-05  1.59680E-05  9.87700E-06  4.00000E-06  3.30000E-06  2.60000E-06  2.10000E-06  1.85500E-06  1.50000E-06  1.30000E-06  1.15000E-06  1.12300E-06  1.09700E-06  1.07100E-06  1.04500E-06  1.02000E-06  9.96000E-07  9.72000E-07  9.50000E-07  9.10000E-07  8.50000E-07  7.80000E-07  6.25000E-07  5.00000E-07  4.00000E-07  3.50000E-07  3.20000E-07  3.00000E-07  2.80000E-07  2.50000E-07  2.20000E-07  1.80000E-07  1.40000E-07  1.00000E-07  8.00000E-08  6.70000E-08  5.80000E-08  5.00000E-08  4.20000E-08  3.50000E-08  3.00000E-08  2.50000E-08  2.00000E-08  1.50000E-08  1.00000E-08  5.00000E-09  1.00000E-11 ];

MACRO_NG                  (idx, 1)        = 2 ;
MACRO_E                   (idx, [1:   3]) = [  1.00000E+37  6.25000E-07  0.00000E+00 ];

% Micro-group spectrum:

INF_MICRO_FLX             (idx, [1: 140]) = [  1.33180E+07 7.5E-05  5.47813E+07 3.4E-05  1.14249E+08 2.1E-05  1.25495E+08 1.9E-05  1.16404E+08 1.5E-05  1.23905E+08 1.6E-05  8.46050E+07 1.5E-05  7.41769E+07 1.6E-05  5.65290E+07 1.7E-05  4.60690E+07 1.9E-05  3.96403E+07 1.9E-05  3.58087E+07 1.9E-05  3.29506E+07 1.9E-05  3.12981E+07 2.0E-05  3.05018E+07 2.1E-05  2.63478E+07 2.0E-05  2.60271E+07 2.1E-05  2.57964E+07 2.2E-05  2.53533E+07 2.2E-05  4.94863E+07 1.6E-05  4.76171E+07 1.6E-05  3.43444E+07 1.9E-05  2.22473E+07 2.4E-05  2.57248E+07 2.1E-05  2.43598E+07 2.1E-05  2.20232E+07 2.3E-05  3.71001E+07 1.8E-05  8.44801E+06 3.7E-05  1.03207E+07 3.2E-05  9.19674E+06 3.6E-05  5.36193E+06 4.4E-05  9.58052E+06 3.7E-05  6.46001E+06 4.3E-05  5.58481E+06 4.0E-05  1.04829E+06 8.5E-05  1.02721E+06 8.1E-05  1.05437E+06 8.5E-05  1.08027E+06 9.1E-05  1.06515E+06 7.9E-05  1.04639E+06 9.6E-05  1.07903E+06 9.2E-05  1.06750E+06 8.3E-05  2.01392E+06 6.7E-05  3.17545E+06 5.6E-05  3.98650E+06 5.3E-05  1.03929E+07 3.2E-05  1.09674E+07 3.1E-05  1.13820E+07 3.3E-05  7.61710E+06 3.5E-05  5.90245E+06 3.6E-05  4.64727E+06 4.2E-05  5.34189E+06 3.5E-05  9.30128E+06 2.8E-05  1.20607E+07 2.8E-05  2.38559E+07 2.3E-05  3.39055E+07 2.1E-05  5.03925E+07 1.9E-05  3.06381E+07 2.1E-05  2.18034E+07 2.2E-05  1.55590E+07 2.4E-05  1.37848E+07 2.5E-05  1.36564E+07 2.5E-05  1.13717E+07 2.8E-05  7.84255E+06 2.9E-05  6.98028E+06 3.0E-05  6.33692E+06 3.3E-05  5.46161E+06 3.3E-05  4.06120E+06 3.6E-05  2.58357E+06 4.1E-05  8.69364E+05 6.5E-05 ];

% Integral parameters:

INF_KINF                  (idx, [1:   2]) = [  9.90250E-01 1.0E-05 ];

% Flux spectra in infinite geometry:

INF_FLX                   (idx, [1:   4]) = [  3.56839E+01 7.1E-06  7.89814E+00 1.2E-05 ];
INF_FISS_FLX              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

INF_TOT                   (idx, [1:   4]) = [  5.56279E-01 2.4E-06  1.48892E+00 3.4E-06 ];
INF_CAPT                  (idx, [1:   4]) = [  6.39191E-03 1.3E-05  4.66746E-02 1.3E-05 ];
INF_ABS                   (idx, [1:   4]) = [  9.02555E-03 1.0E-05  8.58345E-02 1.0E-05 ];
INF_FISS                  (idx, [1:   4]) = [  2.63364E-03 1.1E-05  3.91599E-02 1.2E-05 ];
INF_NSF                   (idx, [1:   4]) = [  6.65146E-03 1.1E-05  9.51689E-02 1.2E-05 ];
INF_NUBAR                 (idx, [1:   4]) = [  2.52558E+00 1.1E-06  2.43027E+00 4.8E-09 ];
INF_KAPPA                 (idx, [1:   4]) = [  2.03231E+02 8.2E-08  2.02270E+02 9.3E-10 ];
INF_INVV                  (idx, [1:   4]) = [  5.84975E-08 9.2E-06  2.46503E-06 3.1E-06 ];

% Total scattering cross sections:

INF_SCATT0                (idx, [1:   4]) = [  5.47254E-01 2.4E-06  1.40308E+00 3.9E-06 ];
INF_SCATT1                (idx, [1:   4]) = [  2.58772E-01 3.9E-06  4.01647E-01 6.3E-06 ];
INF_SCATT2                (idx, [1:   4]) = [  1.02617E-01 6.6E-06  1.05931E-01 1.8E-05 ];
INF_SCATT3                (idx, [1:   4]) = [  7.33539E-03 7.7E-05  3.30747E-02 5.1E-05 ];
INF_SCATT4                (idx, [1:   4]) = [ -1.12097E-02 4.0E-05 -6.59365E-03 0.00021 ];
INF_SCATT5                (idx, [1:   4]) = [ -3.51933E-05 0.01209  6.20454E-03 0.00020 ];
INF_SCATT6                (idx, [1:   4]) = [  5.27082E-03 7.4E-05 -1.76098E-02 6.5E-05 ];
INF_SCATT7                (idx, [1:   4]) = [  7.34117E-04 0.00050 -7.72435E-04 0.00146 ];

% Total scattering production cross sections:

INF_SCATTP0               (idx, [1:   4]) = [  5.47289E-01 2.4E-06  1.40308E+00 3.9E-06 ];
INF_SCATTP1               (idx, [1:   4]) = [  2.58773E-01 3.9E-06  4.01647E-01 6.3E-06 ];
INF_SCATTP2               (idx, [1:   4]) = [  1.02617E-01 6.6E-06  1.05931E-01 1.8E-05 ];
INF_SCATTP3               (idx, [1:   4]) = [  7.33538E-03 7.7E-05  3.30747E-02 5.1E-05 ];
INF_SCATTP4               (idx, [1:   4]) = [ -1.12097E-02 4.0E-05 -6.59365E-03 0.00021 ];
INF_SCATTP5               (idx, [1:   4]) = [ -3.51949E-05 0.01209  6.20454E-03 0.00020 ];
INF_SCATTP6               (idx, [1:   4]) = [  5.27082E-03 7.4E-05 -1.76098E-02 6.5E-05 ];
INF_SCATTP7               (idx, [1:   4]) = [  7.34117E-04 0.00050 -7.72435E-04 0.00146 ];

% Diffusion parameters:

INF_TRANSPXS              (idx, [1:   4]) = [  2.16579E-01 6.2E-06  9.62504E-01 4.5E-06 ];
INF_DIFFCOEF              (idx, [1:   4]) = [  1.53908E+00 6.2E-06  3.46319E-01 4.5E-06 ];

% Reduced absoption and removal:

INF_RABSXS                (idx, [1:   4]) = [  8.99008E-03 1.0E-05  8.58345E-02 1.0E-05 ];
INF_REMXS                 (idx, [1:   4]) = [  2.83621E-02 4.7E-06  8.73626E-02 1.2E-05 ];

% Poison cross sections:

INF_I135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_YIELD          (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_I135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_MICRO_ABS      (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Poison decay constants:

PM147_LAMBDA              (idx, 1)        =  8.37253E-09 ;
PM148_LAMBDA              (idx, 1)        =  1.49451E-06 ;
PM148M_LAMBDA             (idx, 1)        =  1.94297E-07 ;
PM149_LAMBDA              (idx, 1)        =  3.62737E-06 ;
I135_LAMBDA               (idx, 1)        =  2.93061E-05 ;
XE135_LAMBDA              (idx, 1)        =  2.10657E-05 ;
XE135M_LAMBDA             (idx, 1)        =  7.55556E-04 ;
I135_BR                   (idx, 1)        =  8.34911E-01 ;

% Fission spectra:

INF_CHIT                  (idx, [1:   4]) = [  1.00000E+00 9.3E-10  4.98998E-10 0.44361 ];
INF_CHIP                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  2.01219E-10 0.70569 ];
INF_CHID                  (idx, [1:   4]) = [  1.00000E+00 2.4E-08  4.20345E-08 0.57503 ];

% Scattering matrixes:

INF_S0                    (idx, [1:   8]) = [  5.27917E-01 2.4E-06  1.93365E-02 8.1E-06  1.52700E-03 9.6E-05  1.40155E+00 3.9E-06 ];
INF_S1                    (idx, [1:   8]) = [  2.52952E-01 3.9E-06  5.82042E-03 1.9E-05  7.30911E-04 0.00014  4.00916E-01 6.3E-06 ];
INF_S2                    (idx, [1:   8]) = [  1.04257E-01 6.4E-06 -1.63938E-03 5.7E-05  4.27711E-04 0.00018  1.05503E-01 1.8E-05 ];
INF_S3                    (idx, [1:   8]) = [  9.36665E-03 5.9E-05 -2.03126E-03 4.0E-05  1.84966E-04 0.00034  3.28897E-02 5.1E-05 ];
INF_S4                    (idx, [1:   8]) = [ -1.05116E-02 4.2E-05 -6.98127E-04 9.7E-05  4.14714E-05 0.00135 -6.63512E-03 0.00021 ];
INF_S5                    (idx, [1:   8]) = [ -4.10494E-05 0.01018  5.85616E-06 0.01067 -2.52146E-05 0.00187  6.22975E-03 0.00020 ];
INF_S6                    (idx, [1:   8]) = [  5.41951E-03 7.2E-05 -1.48696E-04 0.00037 -5.08737E-05 0.00089 -1.75589E-02 6.5E-05 ];
INF_S7                    (idx, [1:   8]) = [  9.12839E-04 0.00040 -1.78722E-04 0.00030 -5.24729E-05 0.00073 -7.19962E-04 0.00157 ];

% Scattering production matrixes:

INF_SP0                   (idx, [1:   8]) = [  5.27953E-01 2.4E-06  1.93365E-02 8.1E-06  1.52700E-03 9.6E-05  1.40155E+00 3.9E-06 ];
INF_SP1                   (idx, [1:   8]) = [  2.52952E-01 3.9E-06  5.82042E-03 1.9E-05  7.30911E-04 0.00014  4.00916E-01 6.3E-06 ];
INF_SP2                   (idx, [1:   8]) = [  1.04257E-01 6.4E-06 -1.63938E-03 5.7E-05  4.27711E-04 0.00018  1.05503E-01 1.8E-05 ];
INF_SP3                   (idx, [1:   8]) = [  9.36664E-03 5.9E-05 -2.03126E-03 4.0E-05  1.84966E-04 0.00034  3.28897E-02 5.1E-05 ];
INF_SP4                   (idx, [1:   8]) = [ -1.05116E-02 4.2E-05 -6.98127E-04 9.7E-05  4.14714E-05 0.00135 -6.63512E-03 0.00021 ];
INF_SP5                   (idx, [1:   8]) = [ -4.10510E-05 0.01018  5.85617E-06 0.01067 -2.52146E-05 0.00187  6.22975E-03 0.00020 ];
INF_SP6                   (idx, [1:   8]) = [  5.41952E-03 7.2E-05 -1.48696E-04 0.00037 -5.08737E-05 0.00089 -1.75589E-02 6.5E-05 ];
INF_SP7                   (idx, [1:   8]) = [  9.12839E-04 0.00040 -1.78722E-04 0.00030 -5.24729E-05 0.00073 -7.19963E-04 0.00157 ];

% Micro-group spectrum:

B1_MICRO_FLX              (idx, [1: 140]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Integral parameters:

B1_KINF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_KEFF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_B2                     (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_ERR                    (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Critical spectra in infinite geometry:

B1_FLX                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS_FLX               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

B1_TOT                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CAPT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_ABS                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NSF                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NUBAR                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_KAPPA                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_INVV                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering cross sections:

B1_SCATT0                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT1                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT2                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT3                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT4                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT5                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT6                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT7                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering production cross sections:

B1_SCATTP0                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP1                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP2                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP3                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP4                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP5                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP6                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP7                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Diffusion parameters:

B1_TRANSPXS               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_DIFFCOEF               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reduced absoption and removal:

B1_RABSXS                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_REMXS                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Poison cross sections:

B1_I135_YIELD             (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_I135_MICRO_ABS         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

B1_CHIT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHIP                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHID                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

B1_S0                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S1                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S2                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S3                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S4                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S5                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S6                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S7                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering production matrixes:

B1_SP0                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP1                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP2                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP3                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP4                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP5                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP6                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP7                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Additional diffusion parameters:

CMM_TRANSPXS              (idx, [1:   4]) = [  2.30083E-01 1.3E-05  8.77398E-01 5.0E-05 ];
CMM_TRANSPXS_X            (idx, [1:   4]) = [  2.30030E-01 2.0E-05  8.84417E-01 8.0E-05 ];
CMM_TRANSPXS_Y            (idx, [1:   4]) = [  2.30029E-01 2.1E-05  8.84288E-01 8.5E-05 ];
CMM_TRANSPXS_Z            (idx, [1:   4]) = [  2.30190E-01 1.9E-05  8.63815E-01 8.1E-05 ];
CMM_DIFFCOEF              (idx, [1:   4]) = [  1.44875E+00 1.3E-05  3.79911E-01 5.0E-05 ];
CMM_DIFFCOEF_X            (idx, [1:   4]) = [  1.44909E+00 2.0E-05  3.76897E-01 8.0E-05 ];
CMM_DIFFCOEF_Y            (idx, [1:   4]) = [  1.44909E+00 2.1E-05  3.76952E-01 8.5E-05 ];
CMM_DIFFCOEF_Z            (idx, [1:   4]) = [  1.44808E+00 1.9E-05  3.85886E-01 8.1E-05 ];

% Delayed neutron parameters (Meulekamp method):

BETA_EFF                  (idx, [1:  14]) = [  6.86291E-03 0.00018  2.19954E-04 0.00099  1.17207E-03 0.00043  1.14197E-03 0.00043  2.65390E-03 0.00028  1.18235E-03 0.00041  4.92670E-04 0.00066 ];
LAMBDA                    (idx, [1:  14]) = [  5.00442E-01 0.00026  1.33540E-02 5.2E-06  3.26074E-02 5.3E-06  1.21066E-01 2.9E-06  3.05743E-01 6.8E-06  8.61309E-01 1.1E-05  2.89303E+00 1.8E-05 ];

